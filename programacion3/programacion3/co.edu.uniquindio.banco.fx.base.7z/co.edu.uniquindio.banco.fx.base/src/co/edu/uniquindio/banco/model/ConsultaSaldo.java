package co.edu.uniquindio.banco.model;

public class ConsultaSaldo extends Transaccion{

	public ConsultaSaldo() {
		// TODO Auto-generated constructor stub
	}
}
