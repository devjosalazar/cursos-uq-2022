package co.edu.uniquindio.banco.model;

public class CuentaAhorro extends Cuenta{

	public CuentaAhorro() {
		// TODO Auto-generated constructor stub
	}
}
