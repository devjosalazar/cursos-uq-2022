package co.edu.uniquindio.banco.model;

public class Retiro extends Transaccion{

	public Retiro() {
		// TODO Auto-generated constructor stub
	}
}
