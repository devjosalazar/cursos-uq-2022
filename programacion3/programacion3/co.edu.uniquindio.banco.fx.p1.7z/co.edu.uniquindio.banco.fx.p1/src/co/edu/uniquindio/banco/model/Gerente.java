package co.edu.uniquindio.banco.model;

public class Gerente extends Empleado{

	public Gerente() {
		// TODO Auto-generated constructor stub
	}
}
