package co.edu.uniquindio.subasta.controlles;


import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;

public class SubastaWorkerViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {

    }
}